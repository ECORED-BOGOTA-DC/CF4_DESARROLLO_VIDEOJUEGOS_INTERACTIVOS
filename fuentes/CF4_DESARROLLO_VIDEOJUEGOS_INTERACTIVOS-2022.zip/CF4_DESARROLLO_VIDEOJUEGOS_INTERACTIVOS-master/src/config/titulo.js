module.exports = 'Integración de assetts'
